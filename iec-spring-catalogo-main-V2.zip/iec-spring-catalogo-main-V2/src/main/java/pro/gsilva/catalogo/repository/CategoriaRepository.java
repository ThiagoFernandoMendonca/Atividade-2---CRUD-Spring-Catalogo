package pro.gsilva.catalogo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pro.gsilva.catalogo.model.Categoria;

import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface CategoriaRepository extends JpaRepository<Categoria, Long> {

    List<Categoria> findAllByNomeIsLike(String nome);

    @Query("select c from Categoria c where c.nome like :nome")
    List<Categoria> findAllWithNomeLike(String nome);


}
